import pandas as pd
import requests
import xml.etree.ElementTree as ET
import time
import os

# Function to perform API lookup in ALMA
def get_title_and_publication_date_from_alma(barcode, alma_api_url):
    ########################
    # Replace with your API key
    api_key = 'API-KEY'
    ########################

    # Construct the request URL
    url = f"{alma_api_url}/almaws/v1/items?item_barcode={barcode}&apikey={api_key}"

    # Make the API request
    response = requests.get(url)
    if response.status_code == 200:
        # Parse the XML response
        root = ET.fromstring(response.content)

        # Extract title and publication year, removing unwanted characters
        title = root.find('.//title').text.strip('/').replace('/', '').replace('\\', '')
        publication_date = root.find('.//date_of_publication').text.strip('.').replace('.', '')
        mms_id = root.find('.//mms_id').text

        return {'barcode': barcode, 'title': title, 'publication_date': publication_date, 'mms_id': mms_id}
    else:
        # Handle errors
        return {'barcode': barcode, 'error': response.text}

# Function to write ALMA results to the output file
def write_alma_results_to_output(output_file_path, alma_results):
    alma_df = pd.DataFrame(alma_results)
    alma_df.to_csv(output_file_path, mode='w', index=False)

########################
# Read the Excel file into a DataFrame with specified engine
file_path = 'INPUT_PATH'  # Replace with your file path
########################

df = pd.read_excel(file_path, engine='openpyxl')

# Extract barcodes from the DataFrame
barcodes = df.iloc[:, 0]  # Assuming barcodes are in the first column (index 0)

########################
# API base URL for ALMA
alma_api_url = 'https://api-ap.hosted.exlibrisgroup.com'
########################

# Create a list to store ALMA responses
alma_responses = []

# Loop through each barcode and perform API lookup in ALMA
for barcode in barcodes:
    if pd.notna(barcode):  # Check if the cell is not empty
        response = get_title_and_publication_date_from_alma(str(barcode), alma_api_url)
        alma_responses.append(response)

        # Introduce a small delay between requests (e.g., 1 second)
        time.sleep(1)

# Output file path for ALMA results
alma_output_file_path = os.path.join(os.path.dirname(file_path), 'output_ALMA.csv')

# Write ALMA results to the output file
write_alma_results_to_output(alma_output_file_path, alma_responses)

##HERE

# Function to perform API lookup in Trove using ALMA results
def get_trove_info_from_alma_results(title, publication_date):
    
    ########################
    api_key = 'API_KEY'  # Replace with your actual Trove API key
    ########################
    
    query = f"title:'{title}' AND date:[{publication_date} TO {publication_date}]"
    params = {
        'key': api_key,
        'q': query,
        'category': 'all',
        'encoding': 'json',
        'reclevel': 'full',
        'include': 'all',
        'n': 1
    }

    trove_api_url = 'https://api.trove.nla.gov.au/v3/result'

    print(f"Sending request to Trove API for {title} ({publication_date})...")
    response = requests.get(trove_api_url, params=params)

    if response.status_code == 200:
        data = response.json()

        # Attempting to extract book information from the response
        try:
            works = data['category'][0]['records'].get('work', [])
            if works:
                work = works[0]  # Considering only the first work for simplicity
                trove_info = {
                    'Trove Book Title': work.get('title', 'No title found'),
                    'Trove Publication Year': work.get('issued', 'No year found'),
                    'Trove Subjects': ', '.join(work.get('subject', ['No subjects found'])),
                    'Trove URL': work.get('troveUrl', 'No URL found'),
                    'Trove Cultural Sensitive': work.get('culturallySensitive', 'No info'),
                    'Trove First Australians Tag': work.get('firstAustralians', 'No info')
                }
                return trove_info
            else:
                return {'error': f"No works found for {title} ({publication_date}) in Trove."}
        except KeyError as e:
            return {'error': f"Error extracting information: {e}"}
    else:
        return {'error': f"Error in Trove API call: {response.status_code}", 'response': response.text}

# Create a list to store Trove responses
trove_responses = []

# Loop through ALMA results and perform Trove API lookup
for alma_response in alma_responses:
    if 'error' not in alma_response:
        title = alma_response['title']
        publication_date = alma_response['publication_date']

        # Call the function to get Trove information using ALMA results
        trove_response = get_trove_info_from_alma_results(title, publication_date)
        trove_responses.append(trove_response)

        # Print Trove response to the screen
        print(f"Trove response for {title} ({publication_date}):")
        print(trove_response)
    else:
        # Handle cases where ALMA API call had an error
        trove_responses.append({'error': 'ALMA API error', 'barcode': alma_response['barcode']})

# Output file path for combined results
combined_output_file_path = os.path.join(os.path.dirname(file_path), 'output_combined.csv')

# Combine ALMA and Trove results into a single DataFrame
combined_df = pd.DataFrame(alma_responses).copy()  # Corrected variable name
trove_info_df = pd.DataFrame(trove_responses)
combined_df = pd.concat([combined_df, trove_info_df], axis=1)

# Write combined results to the output file
combined_df.to_csv(combined_output_file_path, mode='w', index=False)

print(f"Combined results exported to {combined_output_file_path}")



########################
# Update the file path to the CSV file
csv_file_path = 'output_file' # Replace with output path
########################

# Load the CSV file
df = pd.read_csv(csv_file_path)

########################
# API key and base URL
api_key = 'API_Key' # replace with ALMA API key
base_url = 'https://api-ap.hosted.exlibrisgroup.com/almaws/v1/bibs/'
########################

# Function to fetch holdings ID from ALMA API
def fetch_holdings_id(mms_id):
    url = f'{base_url}{mms_id}/holdings?apikey={api_key}'
    headers = {'accept': 'application/json'}
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        if data['total_record_count'] > 0:
            return data['holding'][0]['holding_id']
        else:
            return 'No holdings found'
    except Exception as e:
        print(f"Failed to fetch data for MMSID {mms_id}: {e}")
        return 'Failed to fetch'

# Function to fetch content from field 925 subfield a
def fetch_field_925a(mms_id, holdings_id):
    url = f'{base_url}{mms_id}/holdings/{holdings_id}?apikey={api_key}'
    headers = {'accept': 'application/json'}
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        data = response.json()
        anies = data.get('anies', [])
        if anies:
            root = ET.fromstring(anies[0])
            for datafield in root.findall('.//datafield[@tag="925"]'):
                subfield_a = datafield.find('subfield[@code="a"]')
                if subfield_a is not None:
                    return subfield_a.text
        return 'No content in field 925 subfield a'
    except Exception as e:
        print(f"Failed to fetch data for MMSID {mms_id}, Holdings ID {holdings_id}: {e}")
        return 'Failed to fetch'

# Adding holdings ID and fetching field 925 subfield a content
df['holdings_id'] = df.iloc[:, 3].apply(fetch_holdings_id)
df['field_925a_content'] = df.apply(lambda row: fetch_field_925a(row.iloc[3], row['holdings_id']), axis=1)

######################## 
# Specify where to save the updated CSV file
updated_csv_file_path = 'output_path'
########################

# Save the updated dataframe to a new CSV file
df.to_csv(updated_csv_file_path, index=False)
