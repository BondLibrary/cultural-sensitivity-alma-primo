import pandas as pd
import requests
import xml.etree.ElementTree as ET

########################
# Load the CSV file
df = pd.read_csv('CSV_FILE_PATH')
########################

# Function to fetch and update content in field 925 subfield a
def handle_field_925a(mms_id, trove_sensitive):
    ########################
    api_key = 'API_KEY'
    ########################
    url = f"https://api-ap.hosted.exlibrisgroup.com/almaws/v1/bibs/{mms_id}?apikey={api_key}"
    headers = {'Accept': 'application/xml', 'Content-Type': 'application/xml'}

    try:
        print(f"Processing MMSID: {mms_id}")
        
        # Fetch the existing record
        response = requests.get(url, headers={'Accept': 'application/xml'})
        response.raise_for_status()
        print("Record fetched successfully")
        
        root = ET.fromstring(response.content)
        record = root.find('.//record')
        if record is None:
            print(f"No <record> element found for MMSID {mms_id}")
            return f"No <record> element found for MMSID {mms_id}"

        # Find or create the 925 field within the record
        datafield_925 = record.find('.//datafield[@tag="925"]')
        if datafield_925 is None:
            datafield_925 = ET.SubElement(record, 'datafield', tag='925', ind1=' ', ind2=' ')
            print("Created new 925 field within record")
        else:
            print("Found existing 925 field within record")
        
        # Find or create subfield a
        subfield_a = datafield_925.find('subfield[@code="a"]')
        if subfield_a is None:
            subfield_a = ET.SubElement(datafield_925, 'subfield', code='a')
            print("Created new subfield a within 925 field")
        else:
            print(f"Found existing subfield a within 925 field with value: {subfield_a.text}")
        
        # Check if update is needed
        update_needed = trove_sensitive == 'Y' and (subfield_a.text is None or subfield_a.text.strip() == '')

        if update_needed:
            # Update subfield a
            subfield_a.text = 'Cultural Advice'
            
            # Convert back to string
            updated_xml = ET.tostring(root, encoding='utf-8', method='xml')
            print(f"Updated XML: {updated_xml.decode('utf-8')}")
            
            # Update the record
            update_url = f"https://api-ap.hosted.exlibrisgroup.com/almaws/v1/bibs/{mms_id}?validate=true&override_warning=true&override_lock=true&stale_version_check=false&check_match=false&apikey={api_key}"
            update_response = requests.put(update_url, headers=headers, data=updated_xml)
            update_response.raise_for_status()
            print(f"Record updated successfully for MMSID: {mms_id}")
            return 'Updated successfully'
        else:
            print(f"No update needed for MMSID: {mms_id}")
        return 'No update needed'
    except requests.exceptions.RequestException as e:
        print(f"HTTP request failed for MMSID {mms_id}: {e}")
        return f"HTTP request failed for MMSID {mms_id}: {e}"
    except ET.ParseError as e:
        print(f"XML parsing failed for MMSID {mms_id}: {e}")
        return f"XML parsing failed for MMSID {mms_id}: {e}"
    except Exception as e:
        print(f"Failed to process MMSID {mms_id}: {e}")
        return f"Failed to process MMSID {mms_id}: {e}"

# Apply the function based on conditions
df['update_status'] = df.apply(lambda row: handle_field_925a(row['mms_id'], row['Trove Cultural Sensitive']), axis=1)
########################
# Save the updated dataframe
df.to_csv('output_file', index=False)
########################
print("Script execution completed")